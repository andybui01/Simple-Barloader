# Simple-Barloader
Generate bar loading graphic for weightlifting meets.

```
pip3 install git+https://github.com/andybui01/Simple-Barloader.git
```

Usage:
```
generate(weight,isMale,OPTIONAL=[file_path='WHERE/TO/SAVE'])
```

Example usage (with resulting graphic):

![M250](https://user-images.githubusercontent.com/22631610/75131525-8da58f00-5727-11ea-9fb8-7c49237e55ea.jpeg)
```
generate(250, True)
```
